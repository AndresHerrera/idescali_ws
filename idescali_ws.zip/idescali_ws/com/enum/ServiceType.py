from enum import IntEnum

class ServiceType(IntEnum):
    WebMapService = 0
    WebMapTileService = 1
