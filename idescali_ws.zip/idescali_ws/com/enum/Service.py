from enum import IntEnum

class Service(IntEnum):
    IDESCaliDataset = 0
