from ..enum.Service import Service

service_url_map = {
    Service.IDESCaliDataset.value: 'http://ws-idesc.cali.gov.co/geoserver/wms?service=WMS&version=1.1.0'
}
