from ..enum.Service import Service

service_text_map = {
    Service.IDESCaliDataset.value: 'Servicios WMS - Web Map Service'
}
