from ..enum.Service import Service
from ..enum.ServiceType import ServiceType


service_type_map = {
    Service.IDESCaliDataset.value: ServiceType.WebMapService.value
}
